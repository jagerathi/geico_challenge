﻿namespace TaskApi.Enums
{
    public enum Priority
    {
        High,
        Medium,
        Low,
    }
}
