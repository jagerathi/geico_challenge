﻿namespace TaskApi.Enums
{
    public enum Status
    {
        New,
        InProgress,
        Finished
    }
}
