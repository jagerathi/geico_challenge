﻿namespace TaskApi.Exceptions
{
    public class InvalidDueDateException : Exception
    {
        
    }
}