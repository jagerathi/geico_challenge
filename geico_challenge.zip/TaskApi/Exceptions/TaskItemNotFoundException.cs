﻿namespace TaskApi.Exceptions
{
    public class TaskItemNotFoundException : Exception
    {
    }
}
