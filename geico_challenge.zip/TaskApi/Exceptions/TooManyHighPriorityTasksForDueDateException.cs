﻿namespace TaskApi.Exceptions
{
    public class TooManyHighPriorityTasksForDueDateException : Exception
    {
    }
}
