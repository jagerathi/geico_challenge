﻿namespace TaskApi.Exceptions
{
    public class InvalidEndDateException : Exception
    {
    }
}
